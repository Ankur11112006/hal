# KISAN SAARTHI — APP BLUEPRINT
### Structure · UI/UX · Theme · Screen-by-screen build sheet
**Companion document to `SPEC.md`. Scope-locked to the 4 Problem Statement features.**

---

## 0. What this document is (and is not)

`SPEC.md` answers **what the app does** — features, data model, ML, backend.
This document answers **what the app looks like and how it is put together** — navigation, screens, theme tokens, folder structure, JSON contracts, and copy-paste prompts for generating the UI.

Nothing here contradicts `SPEC.md` except in **§1.3 (Deltas)**, which lists the three places `SPEC.md` must now be edited.

Read order for anyone joining: `SPEC.md` §1–§3 → this document §2–§6 → back to `SPEC.md` §5–§8.

---

## 1. Scope lock

### 1.1 The only 4 features being built in the app

The Problem Statement asks for exactly four things. Only these four are functional in v1.

| # | Feature | `SPEC.md` ref | Where it lives in the UI |
|---|---|---|---|
| **1** | Crop disease identification | A1 | Camera FAB (centre of bottom bar) → Result screen |
| **2** | Livestock monitoring | B1, B2, B3, B4, B5 | `पशु` tab |
| **3** | Historical farm records | A2, C1 | `रिकॉर्ड` tab (unified timeline) |
| **4** | Actionable advisory | D1, D2, D3 | Mic pill (persistent) + `होम` tab alerts |

Plus the fifth, unstated-but-scored requirement: **"intuitive and accessible interface suitable for rural environments."** That requirement is the reason for every decision in §3 and §4.

### 1.2 Everything else → PPT only, not built

Moved to the **Future Scope** slide. Do not open Android Studio for any of these:

- Mandi price feed (D4), Government schemes (D5)
- WhatsApp channel (E2) — *demo as a slide + screenshot mockup*
- VLAE network (E5), Village outbreak map (E7), Gender lens (E6)
- Photo assist for skin conditions (B6), Year-on-year comparison (C2)
- Entire ROADMAP list in `SPEC.md` §3

**Three new problems from the field conversation** — these are **not new features**. They are already answered by the four we are building, and they belong in the PPT as *problem framing*, amplified with detail:

| Field problem | Already answered by | How to frame it on the slide |
|---|---|---|
| **Middleman / price capture** | Feature 3 (records) + D4 on roadmap | RBI, 16 states, 9,400 respondents: farmer receives **28%** of the consumer price for potato, **33%** onion, **49%** rice. Records are the first step to bargaining power. |
| **Soil** | Feature 3 — `plot.soil_type` field already exists | Soil type is captured at plot registration and feeds the advisory prompt. No new screen. |
| **Weather prediction** | Feature 4 (D3) | IMD's AI monsoon system, launched **11 May 2026**, gives 1 km block-level forecasts 4 weeks ahead across 3,000+ sub-districts. We consume it; we do not build it. |

> Discipline note: adding a screen for any of these breaks the ≤2-tap rule in §3. Amplify them in the *pitch*, not the *build*.

### 1.3 Deltas — three edits `SPEC.md` now needs

| `SPEC.md` location | Currently says | Change to | Why |
|---|---|---|---|
| §6 Architecture box | React Native + Expo | **Kotlin + Jetpack Compose (Android Studio)** | Team decision. Native = smaller APK, better CameraX + TFLite performance on low-end devices. |
| §6 Stack table, "Local store" | expo-sqlite | **Room (SQLite)** | Native equivalent. Same schema, same offline-first behaviour. |
| §6 Stack table, "App" reason | "team already knows it from COTTER" | "native Android, no JS bridge on the camera + inference path" | The old reason no longer applies. |

Everything else in §6 stands: Supabase, FastAPI on Render, Gemini Flash, Bhashini, TFLite INT8.

---

## 2. Design thesis

Three sentences that decide every argument later:

1. **The app has to be usable by someone who cannot read.** Every icon carries a text label, every text block carries a play button, every screen has one primary action.
2. **The app has to be usable in direct noon sunlight, one-handed, with dusty fingers.** Large targets, heavy contrast, no thin grey text, no hover states.
3. **The app must never look more confident than the model is.** The confidence tiers in `SPEC.md` A1 are not a backend detail — they are the colour system. Green = the app is sure. Amber = the app is checking. Red = a human is needed.

Point 3 is the signature. It is the one thing a judge will remember: *an agri app whose visual language is calibrated honesty.*

---

## 3. Navigation — the whole map on one screen

```
┌──────────────────────────────────────────┐
│  [🌐 हिन्दी]      किसान साथी        [⚙]  │  top bar: language always visible
│                                          │
│                                          │
│              screen content              │
│                                          │
│                                          │
│         ╭──────────────────────╮         │
│         │  🎤   पूछो / Ask      │         │  persistent mic pill (Advisory)
│         ╰──────────────────────╯         │
│                                          │
│   ┌────┐  ┌────┐  ╭────╮ ┌────┐ ┌────┐  │
│   │ 🏠 │  │ 🌱 │  │ 📷 │ │ 🐄 │ │ 📋 │  │
│   │होम │  │फसल │  ╰────╯ │पशु │ │रिकॉर्ड│ │
│   └────┘  └────┘   SCAN  └────┘ └────┘  │
└──────────────────────────────────────────┘
```

**Rules that follow from this:**

- **Every one of the 4 features is 1 tap from anywhere.** Nothing is buried in a hamburger menu. There is no hamburger menu.
- **Deepest path in the app is 2 taps.** Scan → Result. Pashu → animal → symptom checker is the only 3-tap flow, and it is a guided wizard, not navigation.
- **Advisory is a mic pill, not a tab.** Advisory is something you *invoke*, not somewhere you *browse*. Answers land in `होम`. This is why there are 4 tabs and 5 features.
- **The camera FAB is the biggest, brightest thing on screen.** It is the most-used action and the demo's opening move.
- **No drawer, no nested tabs, no settings sub-pages beyond one flat list.**

### Screen inventory — 15 screens, no more

| # | Screen | Reached from | Purpose |
|---|---|---|---|
| 0 | Splash | app launch | logo, 800ms, warm the TFLite interpreter |
| 1 | Language picker | first run | pick language before anything is spoken |
| 2–5 | Onboarding slides 1–4 | after language | the problem, the price, the rules, the app |
| 6 | Login (phone + OTP) | after slide 4 | one screen, OTP appears inline |
| 7 | Quick profile | after OTP | name, village, pincode, "khet / pashu / dono" |
| 8 | **Home** | tab 1 | alerts, today, timeline preview, big mic |
| 9 | Camera | FAB | live preview, quality hint |
| 10 | **Scan result** | after capture | 3 visual states by confidence tier |
| 11 | **Crop** | tab 2 | plot list → plot detail → log event |
| 12 | **Livestock** | tab 3 | animal list → animal detail → symptom / milk / vaccine |
| 13 | **Records** | tab 4 | unified timeline, filter chips |
| 14 | Advisory sheet | mic pill | listening → answer card, speaks aloud |
| 15 | Settings | ⚙ | language, voice speed, delete my data |

---

## 4. Theme

### 4.1 Palette

Not a generic "agriculture green" set. The palette is **the confidence system**, plus a soil-warm neutral base that reduces glare outdoors.

| Token | Hex | Role |
|---|---|---|
| `kisan_green` | `#1B5E20` | primary — brand, nav selected, confident results |
| `kisan_green_dark` | `#0F3D14` | pressed state, status bar |
| `kisan_green_soft` | `#DCEFD8` | confident-result card fill, chips |
| `scan_orange` | `#D84315` | **the camera FAB only** — one bright thing, one job |
| `verify_amber` | `#B26A00` | tier 2: "being verified" text + border |
| `verify_amber_soft` | `#FFF3DC` | tier 2 card fill |
| `urgent_red` | `#B3261E` | tier 3, vet-urgent, overdue vaccine |
| `urgent_red_soft` | `#FCEBEA` | tier 3 card fill |
| `bg` | `#FAF8F3` | app background — warm off-white, less glare than pure white |
| `surface` | `#FFFFFF` | cards |
| `outline` | `#D6D3CB` | 1dp borders (we use borders, not shadows) |
| `ink` | `#171512` | primary text |
| `ink_soft` | `#4B4740` | secondary text — **never lighter than this** |

**Contrast floor: 4.5:1 for all text.** `#4B4740` on `#FAF8F3` passes. Anything lighter fails in sunlight and is banned.

**Light mode only in v1.** Dark mode is a Future Scope bullet. Farmers use this outdoors in daylight; dark mode is a demo-room preference, not a field one.

### 4.2 Type

| Role | Face | Size | Weight |
|---|---|---|---|
| Display (onboarding headline) | Noto Sans Devanagari | 32sp | 700 |
| Screen title | Noto Sans Devanagari | 24sp | 700 |
| Card title | Noto Sans Devanagari | 20sp | 600 |
| **Body (default)** | Noto Sans Devanagari | **18sp** | 400 |
| Label / button | Noto Sans Devanagari | 17sp | 600 |
| Caption / source | Noto Sans Devanagari | 14sp | 400 |

- **Noto Sans Devanagari for everything**, including English. One family covers Devanagari, Latin and (via Noto siblings) every other Indian script we add. Mixing a Latin display face with a Devanagari body face is the single most common way Indian-language apps end up looking broken.
- **18sp body is the floor, not a suggestion.** Material's 14sp default is unreadable for a 50-year-old at arm's length in bright light.
- Line height 1.5. Max line length ~40 characters in Hindi.
- **Never all-caps.** Devanagari has no case, so caps buttons force an English/Hindi visual mismatch.

### 4.3 Shape, spacing, targets

- Spacing scale: 4 / 8 / 16 / 24 / 32 dp. Screen padding 16dp.
- Corner radius: cards 16dp, buttons 12dp, FAB circular 72dp.
- **Minimum touch target 56dp. Primary action buttons 64dp tall, full-width.**
- Elevation: **1dp border instead of shadow** everywhere except the FAB. Shadows read as mud on cheap LCD panels.
- Icons: Material Symbols Rounded, 28dp minimum.

### 4.4 Six non-negotiable UI laws

1. **No icon without a text label underneath.** Ever. Not in the nav, not on buttons.
2. **Every screen has exactly one primary action.** If you can name two, split the screen.
3. **Every block of advisory text has a 🔊 play button** wired to Bhashini TTS.
4. **Colour never carries meaning alone.** Every tier state also has an icon and a word: ✓ `पक्का` / ⏳ `जाँच हो रही है` / ⚠ `विशेषज्ञ देखेगा`.
5. **No empty state without an action.** "अभी कोई खेत नहीं जोड़ा" ships with a `+ खेत जोड़ें` button in the same card.
6. **The UI never waits for the network.** Write to Room, render instantly, sync in background (`SPEC.md` §6, rule 3).

### 4.5 Compose theme files

`ui/theme/Color.kt`
```kotlin
package com.kisansaarthi.ui.theme

import androidx.compose.ui.graphics.Color

val KisanGreen      = Color(0xFF1B5E20)
val KisanGreenDark  = Color(0xFF0F3D14)
val KisanGreenSoft  = Color(0xFFDCEFD8)
val ScanOrange      = Color(0xFFD84315)
val VerifyAmber     = Color(0xFFB26A00)
val VerifyAmberSoft = Color(0xFFFFF3DC)
val UrgentRed       = Color(0xFFB3261E)
val UrgentRedSoft   = Color(0xFFFCEBEA)
val Bg              = Color(0xFFFAF8F3)
val Surface         = Color(0xFFFFFFFF)
val Outline         = Color(0xFFD6D3CB)
val Ink             = Color(0xFF171512)
val InkSoft         = Color(0xFF4B4740)
```

`ui/theme/Type.kt`
```kotlin
// font family: res/font/noto_sans_devanagari_{regular,semibold,bold}.ttf
val KisanType = Typography(
    displayLarge = TextStyle(fontFamily = Noto, fontWeight = FontWeight.Bold,     fontSize = 32.sp, lineHeight = 40.sp),
    titleLarge   = TextStyle(fontFamily = Noto, fontWeight = FontWeight.Bold,     fontSize = 24.sp, lineHeight = 32.sp),
    titleMedium  = TextStyle(fontFamily = Noto, fontWeight = FontWeight.SemiBold, fontSize = 20.sp, lineHeight = 28.sp),
    bodyLarge    = TextStyle(fontFamily = Noto, fontWeight = FontWeight.Normal,   fontSize = 18.sp, lineHeight = 27.sp),
    labelLarge   = TextStyle(fontFamily = Noto, fontWeight = FontWeight.SemiBold, fontSize = 17.sp, lineHeight = 24.sp),
    bodySmall    = TextStyle(fontFamily = Noto, fontWeight = FontWeight.Normal,   fontSize = 14.sp, lineHeight = 20.sp)
)
```

`ui/theme/Dimens.kt`
```kotlin
object Dim {
    val screenPad   = 16.dp
    val cardRadius  = 16.dp
    val btnRadius   = 12.dp
    val minTarget   = 56.dp
    val primaryBtnH = 64.dp
    val fabSize     = 72.dp
    val borderW     = 1.dp
}
```

---

## 5. Screen-by-screen

Copy is written **Hindi-first with an English gloss**. Ship Hindi + English in v1; every string lives in `strings_{lang}.json` so more languages are a file drop, not a rebuild (`SPEC.md` E1).

---

### Screen 0 — Splash `800ms`

Logo centred on `bg`. Wordmark **किसान साथी** below. No spinner.
Background work: open the Room DB, load the TFLite interpreter into memory so the first scan is instant.

---

### Screen 1 — Language picker `first run only`

> **Why this comes before the slides:** the slides talk. They cannot talk until we know which language to talk in. Asking for language first is also the cheapest possible trust signal — the app speaks *your* language before it asks for anything.

- Title: **भाषा चुनें / Choose language** (shown in both, since we do not know yet)
- 2-column grid of 64dp-tall tiles. **Each language written in its own script**, never transliterated: `हिन्दी` `English` `मराठी` `ਪੰਜਾਬੀ` `বাংলা` `తెలుగు`
- Tapping a tile **speaks a one-line sample aloud** before confirming. This is the tell that the app is voice-capable.
- v1 ships Hindi + English functional; the rest are visible but marked `जल्द आ रहा है`. **Do not fake them** — a judge will tap one.
- Selection stored in DataStore. Changeable forever from the 🌐 in the top bar.

---

### Screens 2–5 — Onboarding, 4 slides

**Layout, identical on all four:**

```
┌────────────────────────────┐
│                            │
│      illustration          │  55% of screen, full-bleed
│                            │
├────────────────────────────┤
│  BIG NUMBER                │  40sp, kisan_green
│  Headline (2 lines max)    │  32sp bold
│  One supporting line       │  18sp, ink_soft
│  स्रोत: XYZ                 │  14sp, ink_soft   ← source line, always
│                            │
│  ● ○ ○ ○        [ आगे → ] │  dots + 64dp primary button
│  छोड़ें                      │  skip, text button, top-right corner
└────────────────────────────┘
```

Each slide auto-plays a one-line voice-over (🔊 button to replay). Swipe or button to advance. Shown once — flag in DataStore — and re-openable from Settings.

**The source line on every slide is deliberate.** These are real numbers from real studies. Printing the source is how the app earns the trust that `SPEC.md` §2 Fact 1 says is the actual bottleneck. It also stops a judge asking "where did that come from?"

---

#### Slide 1 — The loss

> **26%**
> **हर साल फसल कीट और बीमारी से बर्बाद होती है**
> सही समय पर सलाह मिले तो नुकसान 10% तक घट सकता है।
> *स्रोत: Ama Krushi RCT, ओडिशा सरकार / PxD*

*The loss from pest and disease. Timely advisory has been shown to cut severe crop loss by 10%.*
Illustration: a diseased maize leaf, close, honest, not stylised.

---

#### Slide 2 — The price

> **28%**
> **आलू के दाम का सिर्फ इतना हिस्सा किसान तक पहुँचता है**
> प्याज़ 33%, चावल 49%। बाकी बीच में चला जाता है।
> *स्रोत: RBI अध्ययन, 16 राज्य, 9,400 किसान*

*Of the consumer price, this is the farmer's share. The rest is captured in between.*
This is the middleman slide. It is the slide that makes the room lean in, and it costs us nothing to build because it is a statistic, not a feature.
Illustration: a simple bar splitting one rupee — the farmer's slice small and green, the rest grey.

---

#### Slide 3 — The new rules

> **7.63 करोड़**
> **किसान अब डिजिटल पहचान से जुड़ चुके हैं**
> AgriStack Farmer ID · DPDP क़ानून 2023 — आपका डेटा आपका है, कभी भी मिटा सकते हैं · IMD का नया AI मौसम अनुमान, 1 किमी तक, 4 हफ़्ते पहले (11 मई 2026 से)
> *स्रोत: DAHD · IMD*

*The rules changed. Digital farmer IDs, a data-protection law that puts the farmer in control, and block-level AI weather forecasting.*
Frame as opportunity, not compliance. This slide is also where we quietly plant "we are built on India's own Digital Public Infrastructure" — judges score it (`SPEC.md` E1).

---

#### Slide 4 — What this app is

No statistic. This slide is a **labelled diagram of the actual home screen**, with four callouts drawn onto it:

```
📷  →  "पत्ता दिखाओ, बीमारी पहचानो"     (scan lives here, big, in the middle)
🎤  →  "बोलकर पूछो, जवाब सुनो"          (ask anything, any time)
🐄  →  "पशु का टीका, दूध, बीमारी"        (livestock tab)
📋  →  "खेत और पशु — एक ही जगह"        (records tab)
🌐  →  "भाषा यहाँ बदलें"                 (language, top-left, always there)
```

Button text changes to **शुरू करें** (Get started).

> This slide is doing a specific job: after it, the user has already seen the home screen once, so the real home screen feels familiar instead of new. It replaces a tutorial overlay, which nobody reads.

---

### Screen 6 — Login

One screen. Phone + OTP, no email, no password (`SPEC.md` §6, auth row).

- Title: **मोबाइल नंबर डालें**
- `+91` prefix fixed and greyed. 10-digit numeric field, 24sp, letter-spaced, keyboard opens automatically.
- Primary button: **OTP भेजें** (64dp, full width)
- After send, the field slides up and a 6-box OTP row appears **on the same screen** — no navigation. SMS Retriever API auto-fills.
- Resend as a 30-second countdown text button.
- Errors are specific: **"यह नंबर 10 अंकों का नहीं है"**, not "Invalid input".
- 🔊 on the instruction line.

---

### Screen 7 — Quick profile

Four fields, one screen, **no land title required** (`SPEC.md` E6 — this exclusion is a deliberate design position and worth one line in the PPT).

1. नाम — text
2. गाँव — text
3. पिनकोड — 6-digit numeric
4. **आप क्या करते हैं?** — three large image-cards: `खेती` / `पशुपालन` / `दोनों`

Q4 decides which tab opens first and what the home screen leads with. It is the only branching the app does.
Button: **आगे बढ़ें**. A skip is allowed on 1–3; Q4 is required.

---

### Screen 8 — Home

The home screen answers one question: **"मुझे आज क्या करना है?"** (What do I do today?) It is not a dashboard. There are no charts.

```
┌────────────────────────────────────┐
│ 🌐 हिन्दी      किसान साथी        ⚙  │
├────────────────────────────────────┤
│ ☀ 32° · कल बारिश                🔊 │  weather strip, 1 line
├────────────────────────────────────┤
│ ⚠ आज ज़रूरी                        │  urgent card — only if something is
│ गौरी का FMD टीका 12 दिन में       │  actually due. Never a filler card.
│ [ याद दिलाओ ]                      │
├────────────────────────────────────┤
│ हाल की गतिविधि                      │
│ 12 अग · प्लॉट A · झुलसा 87%       │  last 3 timeline rows only
│ 10 अग · गौरी · 5.2 लीटर दूध        │
│ [ सब देखें → ]                     │
└────────────────────────────────────┘
        ╭─────────────────────╮
        │  🎤  कुछ भी पूछो     │
        ╰─────────────────────╯
   होम    फसल   [📷]   पशु   रिकॉर्ड
```

- **Alert cards obey `SPEC.md` D2**: what / when / how much / why, plus cost-benefit. Threshold-triggered only. If nothing crossed a threshold, no card appears — an empty urgent section is a *feature*, and it is what prevents alert fatigue.
- Weather strip is one line. Tapping it does nothing in v1. Do not build a weather screen.
- Answers from the mic land here as cards, so the advisory feature has a persistent home without owning a tab.

---

### Screen 9 — Camera

- Full-bleed CameraX preview. Nothing on screen except:
  - A rounded guide frame, `kisan_green` outline
  - One instruction line at the top: **"पत्ते को पास से, रोशनी में"**
  - A 72dp white shutter button
  - A gallery thumbnail (bottom-left) and a flash toggle (top-right)
- **Live quality hint:** run the Laplacian-variance check (`SPEC.md` A1) on the preview stream. If blurry or dark, the guide frame turns `verify_amber` and the line changes to **"थोड़ा पास आओ / ज़्यादा रोशनी चाहिए"**. The shutter stays enabled — never block the farmer, just warn.
- No filters, no zoom UI, no aspect-ratio picker.

---

### Screen 10 — Scan result `the most important screen in the app`

Three visual states. Same layout, three skins. The skin *is* the honesty.

**Tier 1 — confidence > 0.85** — `kisan_green` border, `kisan_green_soft` fill, ✓ icon
```
✓ पक्का — मक्का का झुलसा रोग                87%
गंभीरता: स्तर 2 (मध्यम)                        🔊
─────────────────────────────────────────
क्या करें    मैंकोज़ेब 2.5 ग्राम / लीटर
कब          आज शाम 4 बजे से पहले (कल बारिश है)
खर्चा        ₹380
बचत          लगभग ₹3,000 का नुकसान बचेगा
─────────────────────────────────────────
[ रिकॉर्ड में जोड़ें ]   ← single primary action
```

**Tier 2 — 0.60–0.85** — `verify_amber` border, `verify_amber_soft` fill, ⏳ icon
```
⏳ शायद मक्का का झुलसा — जाँच हो रही है     72%
गाँव के सलाहकार को भेज दिया है।
जवाब आते ही आपको बताएँगे।                   🔊
[ ठीक है ]
```
No treatment plan is shown. Showing a dosage at 72% confidence is exactly the failure mode `SPEC.md` §2 Fact 1 is written to prevent.

**Tier 3 — below 0.60** — `urgent_red` border, `urgent_red_soft` fill, ⚠ icon
```
⚠ हम पक्का नहीं बता सकते
इसे विशेषज्ञ देख रहे हैं। 4 घंटे में जवाब मिलेगा। 🔊
[ 📞 1962 पर बात करें ]
[ दूसरी फ़ोटो लें ]
```
**No disease name is shown at all.** Not even a guess.

> **Demo instruction:** Step 3 of the demo script in `SPEC.md` §10 is the Tier 2/3 screen. Rehearse the line: *"It refuses to guess. That refusal is why a farmer trusts it the second time."* This screen is worth more marks than the Tier 1 screen.

Every tier writes an `event` row immediately, offline, before any network call.

---

### Screen 11 — फसल (Crop)

**List view:** plot cards — name, crop, area, sowing date, a status dot.
Empty state: illustration + **"अभी कोई खेत नहीं जोड़ा"** + `[ + खेत जोड़ें ]` in the same card.

**Add plot:** name, area (bigha), soil type (dropdown — this is where the soil problem is answered), GPS auto-fill with a manual override.

**Plot detail:** header, then a vertical list of that plot's events, then a single FAB-less bottom button: `[ + कुछ दर्ज करें ]` opening a bottom sheet of 6 chips — बुवाई · सिंचाई · छिड़काव · खाद · कटाई · खर्च.

**Voice logging** (`SPEC.md` A2): the mic pill works inside this screen too. "मक्का बोया, 15 जून, 2 बीघा" → parsed → a pre-filled form shown for confirmation. **Always show the parsed form before saving.** Never save straight from speech.

---

### Screen 12 — पशु (Livestock)

**List:** animal cards with photo, name, species, and a status chip: `टीका बाकी` (red) / `दूध कम` (amber) / `ठीक` (green).

**Animal detail** — four large action tiles, 2×2 grid, each 96dp, icon + label:
```
┌──────────────┬──────────────┐
│  🩺 बीमारी?   │  🥛 दूध दर्ज  │
├──────────────┼──────────────┤
│  💉 टीका      │  📅 प्रजनन    │
└──────────────┴──────────────┘
```
Below the grid: that animal's recent events.

**Symptom checker** (the only wizard in the app): one question per screen, two huge 96dp answer buttons `हाँ` / `नहीं`, a progress bar, and a back arrow. Questions are read aloud automatically. 3–6 questions, driven by `symptom_tree.json`, fully offline.
Result card uses the same three-tier skins as Screen 10. An `urgent` branch shows `[ 📞 1962 ]` as the single primary action.

**Milk log:** a numeric pad, not a text field. Big digits. Auto-fills today's date. If the anomaly rule fires (<85% of 7-day average for 3 days), an amber card appears immediately with the mastitis/heat-stress line from `SPEC.md` B4.

**Vaccination:** upcoming and overdue list, one `[ हो गया ]` button per row.

---

### Screen 13 — रिकॉर्ड (Records)

**This is the screen the whole product is designed around** (`SPEC.md` C1). One chronological feed, crops and animals interleaved.

- Filter chips at top: `सब` · `फसल` · `पशु`. **Default is `सब`** — and it must stay `सब`, because the merged view *is* the differentiator. Splitting it by default would hide the one thing no competitor has.
- Row: date · icon (🌱 or 🐄) · subject · one-line description · optional thumbnail.
- Crop rows tint `kisan_green_soft`, animal rows `surface`. Subtle — enough to read the mix at a glance, not enough to look like two lists.
- Grouped by month with sticky headers.
- Tap a row → the source detail screen.

Demo note: this is step 5 of the 2-minute script. Scroll it slowly. The interleaving is the point.

---

### Screen 14 — Advisory sheet

Opens as a bottom sheet over whatever screen you were on. Never a full navigation.

1. **Listening:** large animated mic, live waveform, **"सुन रहे हैं…"**, a cancel button.
2. **Thinking:** the transcribed question shown as text so the farmer can see it was heard correctly, plus a three-dot indicator.
3. **Answer:** a card, max 4 lines (`SPEC.md` D1 prompt constraint), auto-played aloud on arrival, with:
   - 🔊 replay
   - Source line: **"ICAR के अनुसार"**
   - 👍 / 👎 (down-votes route to expert review)
   - `[ रिकॉर्ड में सहेजें ]`
4. **Offline:** **"नेटवर्क आने पर जवाब मिलेगा"** — question is queued, and this is a *success* state, styled green, not an error.

Also accepts typed input via a small keyboard toggle, for the literate power user and — practically — for demoing in a noisy hall.

---

### Screen 15 — Settings

One flat list. Six rows. No sub-pages except language.

`भाषा बदलें` · `आवाज़ की गति` · `स्लाइड फिर देखें` · `मेरा डेटा मिटाएँ` · `मदद / 1962` · `ऐप के बारे में`

**"मेरा डेटा मिटाएँ"** is DPDP Act 2023 compliance (`SPEC.md` E8) and must report the count of records deleted. One line, one screenshot, and it is a scoring point in the PPT.

---

## 6. Project structure

Create these packages and files empty first, then fill in. Everything compiles from day one; nobody blocks on anybody.

```
app/src/main/java/com/kisansaarthi/
│
├── KisanApp.kt                     Application class, DI init
├── MainActivity.kt                 single activity, hosts NavHost
│
├── ui/
│   ├── theme/
│   │   ├── Color.kt                §4.5
│   │   ├── Type.kt                 §4.5
│   │   ├── Dimens.kt               §4.5
│   │   └── Theme.kt                KisanTheme { }
│   │
│   ├── components/                 shared, build these FIRST
│   │   ├── PrimaryButton.kt        64dp, full width, one per screen
│   │   ├── KisanCard.kt            16dp radius, 1dp border, no shadow
│   │   ├── TierCard.kt             ★ green / amber / red result card
│   │   ├── SpeakButton.kt          ★ 🔊 wired to Bhashini TTS
│   │   ├── MicPill.kt              ★ persistent advisory launcher
│   │   ├── LabeledIcon.kt          enforces "no icon without a label"
│   │   ├── BigYesNo.kt             96dp symptom-checker buttons
│   │   ├── EmptyState.kt           illustration + text + action
│   │   └── KisanBottomBar.kt       4 tabs + centre FAB
│   │
│   ├── onboarding/
│   │   ├── SplashScreen.kt
│   │   ├── LanguageScreen.kt
│   │   ├── OnboardingScreen.kt     pager, reads onboarding.json
│   │   └── OnboardingViewModel.kt
│   ├── auth/
│   │   ├── LoginScreen.kt          phone + inline OTP
│   │   ├── ProfileScreen.kt
│   │   └── AuthViewModel.kt
│   ├── home/          HomeScreen.kt · HomeViewModel.kt
│   ├── crop/          CropScreen.kt · PlotDetailScreen.kt · AddPlotScreen.kt · CropViewModel.kt
│   ├── scan/          CameraScreen.kt · ScanResultScreen.kt · ScanViewModel.kt
│   ├── livestock/     LivestockScreen.kt · AnimalDetailScreen.kt · SymptomCheckerScreen.kt
│   │                  MilkLogScreen.kt · VaccinationScreen.kt · LivestockViewModel.kt
│   ├── records/       RecordsScreen.kt · RecordsViewModel.kt
│   ├── advisory/      AdvisorySheet.kt · AdvisoryViewModel.kt
│   ├── settings/      SettingsScreen.kt
│   └── nav/           KisanNavHost.kt · Routes.kt
│
├── data/
│   ├── local/
│   │   ├── KisanDatabase.kt        Room
│   │   ├── entity/                 Farmer · Plot · Animal · Event · Advisory  ← SPEC.md §5, exactly
│   │   ├── dao/                    FarmerDao · PlotDao · AnimalDao · EventDao · AdvisoryDao
│   │   └── PrefsStore.kt           DataStore: language, onboarding_seen, session
│   ├── remote/
│   │   ├── KisanApi.kt             Retrofit → FastAPI
│   │   ├── SupabaseAuth.kt         phone OTP
│   │   └── dto/
│   ├── repository/
│   │   ├── EventRepository.kt      ★ every write goes through here
│   │   ├── ScanRepository.kt
│   │   ├── AdvisoryRepository.kt
│   │   └── SyncManager.kt          WorkManager, flush queue on connectivity
│   └── json/                       loaders for the files in §7
│
├── ml/
│   ├── CropClassifier.kt           TFLite interpreter, INT8
│   ├── ImageQualityCheck.kt        Laplacian variance
│   ├── ConfidenceRouter.kt         ★ >0.85 / 0.60–0.85 / <0.60 → tier
│   └── SymptomTreeEngine.kt        walks symptom_tree.json, offline
│
├── voice/
│   ├── BhashiniTts.kt              speak(text, lang)
│   ├── BhashiniAsr.kt              listen(audio, lang)
│   └── LocaleManager.kt            loads strings_{lang}.json
│
└── util/                           DateUtils · NetworkMonitor · Constants

app/src/main/assets/
├── crop_model.tflite               ~5MB, bundled in APK
├── labels.txt
├── symptom_tree.json
├── treatment_plans.json
├── vaccination_schedule.json
├── onboarding.json
└── strings_hi.json · strings_en.json

app/src/main/res/
├── font/       noto_sans_devanagari_{regular,semibold,bold}.ttf
├── drawable/   onboarding illustrations, empty-state art, logo
└── values/     colors.xml (mirror of Color.kt) · themes.xml
```

**Build the five ★ components first.** They carry the design system. Once `TierCard`, `SpeakButton`, `MicPill`, `EventRepository` and `ConfidenceRouter` exist, every screen after that is assembly.

---

## 7. JSON contracts

Content lives in JSON, not in Kotlin. That means the pitch copy, the vet logic and the treatment plans can all be edited the night before the demo without a rebuild — and by someone who is not the Android dev.

**`onboarding.json`**
```json
{
  "slides": [
    {
      "id": 1,
      "illustration": "slide_loss",
      "stat":     { "hi": "26%",        "en": "26%" },
      "headline": { "hi": "हर साल फसल कीट और बीमारी से बर्बाद होती है",
                    "en": "Lost to pest and disease every year" },
      "body":     { "hi": "सही समय पर सलाह मिले तो नुकसान 10% तक घट सकता है।",
                    "en": "Timely advisory has cut severe crop loss by 10%." },
      "source":   "Ama Krushi RCT, Govt of Odisha / PxD",
      "voice_over": { "hi": "...", "en": "..." }
    }
  ]
}
```

**`symptom_tree.json`** — 40–60 nodes (`SPEC.md` B3)
```json
{
  "root": "fever",
  "nodes": {
    "fever": {
      "q": { "hi": "क्या बुखार है?", "en": "Does it have fever?" },
      "yes": "off_feed", "no": "milk_drop"
    },
    "off_feed": {
      "q": { "hi": "क्या खाना छोड़ दिया?", "en": "Has it stopped eating?" },
      "yes": "result_urgent_01", "no": "udder_swelling"
    }
  },
  "results": {
    "result_urgent_01": {
      "likely":  { "hi": "संक्रमण की आशंका", "en": "Possible infection" },
      "action":  { "hi": "तुरंत डॉक्टर को दिखाएँ", "en": "See a vet immediately" },
      "urgency": "urgent",
      "needs_vet": true
    }
  }
}
```

**`treatment_plans.json`** — keyed by model label. Each entry: `what` / `dose` / `when` / `cost_inr` / `saves_inr` / `source`. These five fields are exactly what the Tier 1 card renders, so the card needs zero logic.

**`vaccination_schedule.json`** — FMD, HS, BQ, Brucella, deworming with interval-in-days and species.

**`strings_hi.json` / `strings_en.json`** — every UI string. Adding a language = adding a file. **No hardcoded strings in Kotlin. Not one.**

---

## 8. UI generation — Stitch prompts

Paste these into Google Stitch one at a time, export, then hand the screenshots plus this document to Claude to convert into Compose. Prefix every prompt with this block:

> **Style block (prepend to every prompt):**
> Android mobile app for Indian farmers. Light mode only. Background #FAF8F3, cards white with a 1dp #D6D3CB border and 16dp radius, no drop shadows. Primary green #1B5E20, alert amber #B26A00, urgent red #B3261E, camera button #D84315. Font: Noto Sans Devanagari. Body text 18sp minimum, buttons 64dp tall and full width. All labels in Hindi (Devanagari script). Every icon has a text label under it. Large touch targets, very high contrast, designed to be readable in bright sunlight. Minimal — one primary action per screen. No gradients, no glassmorphism, no illustrations of smiling stock-photo farmers.

| # | Screen | Prompt |
|---|---|---|
| 1 | Language | "Language selection screen. Title in Hindi and English. A 2-column grid of six large tap tiles, each showing a language written in its own script — हिन्दी, English, मराठी, ਪੰਜਾਬੀ, বাংলা, తెలుగు. Each tile has a small speaker icon. Bottom four tiles are dimmed with a small 'जल्द आ रहा है' tag." |
| 2 | Onboarding | "Onboarding slide. Top 55% is an illustration of a diseased maize leaf. Below: a very large green statistic '26%', a bold two-line Hindi headline, one line of supporting text, a small grey source line, four page dots with the first filled, a full-width green 'आगे' button, and a small 'छोड़ें' text link in the top right corner." |
| 3 | Login | "Phone login screen. Hindi title 'मोबाइल नंबर डालें'. A fixed '+91' prefix and a large 10-digit number field with wide letter spacing. A full-width green 'OTP भेजें' button. Below it, a row of six separate square OTP input boxes. A grey resend countdown line." |
| 4 | Home | "Farmer app home screen. Top bar with a globe icon and 'हिन्दी' on the left, the title 'किसान साथी' centred, a settings gear on the right. A one-line weather strip. A red-bordered urgent card reading 'गौरी का FMD टीका 12 दिन में' with a button. A 'हाल की गतिविधि' section with three compact rows mixing crop and animal entries. Floating above the bottom bar, a wide green pill button with a microphone icon reading 'कुछ भी पूछो'. Bottom navigation with four labelled tabs — होम, फसल, पशु, रिकॉर्ड — and a large circular orange camera button raised in the centre." |
| 5 | Scan result | "Crop disease result screen. A card with a thick green border and pale green fill, a checkmark, the Hindi disease name 'मक्का का झुलसा रोग', an '87%' badge, and a speaker icon. Inside, four labelled rows: क्या करें, कब, खर्चा, बचत. One full-width green button 'रिकॉर्ड में जोड़ें' at the bottom." |
| 6 | Scan result, uncertain | "Same layout as the previous screen but amber: thick #B26A00 border, pale #FFF3DC fill, an hourglass icon, headline 'शायद मक्का का झुलसा — जाँच हो रही है', a 72% badge, two lines of Hindi explanation, no treatment details at all, and one outlined button 'ठीक है'." |
| 7 | Livestock | "Animal detail screen. A header with a cow photo, the name 'गौरी', and breed. Below it a 2×2 grid of four large square action tiles, each with a big icon and a Hindi label: बीमारी?, दूध दर्ज, टीका, प्रजनन. Below the grid, a list of recent activity rows with dates." |
| 8 | Symptom checker | "Full-screen single-question wizard. A thin progress bar at the top showing step 2 of 5. A large Hindi question 'क्या खाना छोड़ दिया?' with a speaker icon. Two enormous stacked buttons, 'हाँ' in green and 'नहीं' in white with a green outline, each about a quarter of the screen height. A back arrow top-left. Nothing else on screen." |
| 9 | Records | "Unified timeline screen. Three filter chips at the top — सब (selected), फसल, पशु. Below, a scrolling list grouped by month with sticky '<month> headers'. Rows alternate between crop entries with a pale green tint and a plant icon, and animal entries on white with a cow icon. Each row shows a date, a subject name, and one line of description. Some rows have a small square thumbnail on the right." |
| 10 | Advisory | "Bottom sheet over a dimmed home screen. At the top, the transcribed question in Hindi as grey text. Below, a white answer card with four lines of Hindi advice, a speaker icon, a small source line reading 'ICAR के अनुसार', thumbs-up and thumbs-down icons, and a full-width button 'रिकॉर्ड में सहेजें'." |

---

## 9. Build order

Ten steps, sequenced so something is demoable at every stage. If time runs out, stop at any step and you still have a working app.

| Step | Deliverable | Unblocks |
|---|---|---|
| 1 | Theme files + the five ★ components | everything |
| 2 | Room entities + DAOs (`SPEC.md` §5 verbatim, **one `event` table**) | all data work |
| 3 | Nav host + bottom bar + 4 empty tab screens | parallel screen work |
| 4 | Language → onboarding → login → profile | first run is complete |
| 5 | Add plot, add animal | there is data to show |
| 6 | Records timeline | the differentiator is visible |
| 7 | CameraX + TFLite + `ConfidenceRouter` + `TierCard` | **the demo's centrepiece** |
| 8 | Symptom checker from JSON | livestock is real |
| 9 | Advisory sheet + Bhashini TTS/ASR | **step 6 of the demo script** |
| 10 | Milk log, vaccination reminders, sync, airplane-mode test | polish |

**The single hardest deadline is step 7.** It depends on the trained model. Start the Colab training run (`SPEC.md` §4.1) in parallel with step 1, not at step 7. Until the real `.tflite` exists, ship a stub `CropClassifier` that returns a fixed label and a configurable confidence — that stub also makes rehearsing all three tier screens trivial.

---

## 10. Checklist before the demo

- [ ] Airplane mode: scan works, symptom checker works, writes queue, timeline renders
- [ ] All three tier states reachable on demand (keep a known-hard leaf photo in the gallery)
- [ ] Every visible string is Hindi and comes from `strings_hi.json`
- [ ] Zero icons without labels
- [ ] Every advisory block has a working 🔊
- [ ] Screen brightness at 100% — check contrast on the actual demo phone, not the emulator
- [ ] Timeline has at least 8 rows mixing crop and animal, dated realistically
- [ ] `मेरा डेटा मिटाएँ` works and reports a real count
- [ ] APK installs on a low-end device and cold-starts in under 3 seconds
- [ ] The 2-minute script (`SPEC.md` §10) rehearsed end to end, twice

---

## 11. Open items — need a decision from you

1. **Illustrations for the four onboarding slides.** Photos or flat vector? Recommendation: real photographs for slide 1 (a genuinely diseased leaf carries more weight than an icon), flat vector for 2–4. Someone needs to source or draw five assets.
2. **Languages in v1.** Recommendation: Hindi + English functional, four more visible but tagged `जल्द आ रहा है`. Confirm the four.
3. **The "new rules" slide.** Currently AgriStack + DPDP + IMD, all from `SPEC.md` §11. If a state-specific Rajasthan scheme is more relevant to the judges, swap it in — **but only with a source**, per §5.
4. **Minimum Android version.** Recommendation: API 24 (Android 7.0). Lower means dropping some Compose conveniences; higher excludes real farmer devices.
5. **Who owns the Colab training run?** It is the critical path for step 7 and nothing about the UI can unblock it.

---

*Every number in this document traces to `SPEC.md` §11 (Verified numbers). Nothing new has been invented. If a figure is added later, it goes in that table first, with a source, or it does not go on a slide.*

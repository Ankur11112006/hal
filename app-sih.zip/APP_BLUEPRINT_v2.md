# BAHI — APP BLUEPRINT v2
### बही · खेत और पशु, एक ही बही में
**Structure · UI/UX · Theme · Screen-by-screen · Demo defence**
Companion to `SPEC.md`. Supersedes `APP_BLUEPRINT.md` (v1).

---

## 0. What changed from v1, and why

v1 was a good UI document attached to a pitch with five holes in it. A mock jury review found them. v2 closes all five inside the design, not in the slides.

| # | Problem found | Fix in v2 |
|---|---|---|
| 1 | **Name + competitor collision.** "Kisan Saarthi" is a live Government of India / ICAR–MeitY platform with ~2.95 crore registered farmers, integrating Bhashini, IMD, MyScheme and KCC, with advisories covering crops *and* livestock, poultry and fisheries. The `SPEC.md` §9 competitor table missed it. | Renamed. Kisan Sarathi added as competitor row one **and turned into our expert-escalation partner** (§2, §9) |
| 2 | **Cold start.** The unified timeline — the entire differentiator — is empty on day one and only fills if a low-literacy user logs data faithfully for months. | New **§4 Day Zero** design. The app now produces a populated timeline with *zero* manual logging |
| 3 | **Escalation to nowhere.** Tiers 2 and 3 are ~30% of scans and routed to a VLAE queue that was cut from the build. | New **§9 Escalation** — every tier terminates at a real, dialable, logged endpoint |
| 4 | **Weak demo line.** "Use the stover as fodder" is something Indian farmers have done for generations. | Replaced with the cross-domain line that is actually impossible for competitors (§14) |
| 5 | **"One event table is our moat."** A schema is a week of work for a competitor. | Moat restated as three things nobody else has together (§2.3) |

Also new in v2: motion and accessibility specs (§6.5–6.6), a component spec table with real dimensions (§7), a risk register (§13), a model card slide (§14.2), and a **judge Q&A defence** (§15).

---

## 1. Naming

`Kisan Saarthi` cannot be used. It is the name of an existing flagship government platform, and using it in front of an ICAR-affiliated jury reads as either ignorance or imitation.

**Recommended: बही / BAHI**

The *bahi* is the traditional handwritten farm ledger — the book where a family recorded what was sown, what was spent, which animal calved. It is the exact object we are digitising, it is instantly understood in Hindi-belt villages, it is two syllables, and it names the differentiator rather than the sector.

> **Tagline:** खेत और पशु, एक ही बही में — *Field and animal, in one ledger.*

Alternates if BAHI is taken: **पंजिका / PANJIKA** (register) · **रोज़नामचा / ROZNAMCHA** (the daily record; also a Rajasthan revenue-department term, so it carries official weight locally).

**Before locking:** search the Play Store and the trademark register. Ten minutes now, versus the question you cannot answer on stage. If you pick a different name, find-and-replace `BAHI` and `बही` throughout this document and `strings_*.json`.

---

## 2. Positioning

### 2.1 The honest competitive picture

| Platform | Reach | What it structurally cannot do |
|---|---|---|
| **Kisan Sarathi** (ICAR + MeitY) | ~2.95 crore registered, 4,767 scientists, 113 institutes; integrates KCC, IMD, MyScheme, Bhashini; covers crop **and** livestock | Query-in, advisory-out. **No per-farmer longitudinal record.** No on-device offline diagnosis. And of ~2.95 crore registrations, ~2.89 crore came from physically visiting a KVK while only ~21,517 came through mobile apps |
| Plantix | 100M+ queries | Crop only. No animals, no records. Monetised on agri-input sales |
| PlantVillage Nuru | offline on-device | Crop only, few crops; 14.1% documented field adoption |
| Bharat Pashudhan | 29.6 of 30.5 crore bovines tagged | Built for paravets, not farmers. No disease help |
| Ama Krushi | 7M farmers, $9–15 return per $1 | One-way. Farmer cannot ask. Crop only |
| iCow (Kenya) | +13% milk, +22% household income | Dairy only |

### 2.2 The reframe that makes us safe *and* stronger

We are **not** a competitor to Kisan Sarathi. We are the layer it does not have.

> Kisan Sarathi is the country's expert *answer* network. It has scientists, reach and legitimacy. What it does not have is a structured, longitudinal, offline-first record of what actually happened on one farmer's plot and to one farmer's animals — because that record can only be captured in the field, at the moment it happens, without a network.
>
> **BAHI captures. Kisan Sarathi answers.** Our low-confidence cases escalate *into* the government's expert network, and our event log is exactly the context those experts currently have to ask for over the phone.

That sentence converts the biggest threat in the room into your strongest slide. Say it before a judge says it to you.

### 2.3 What the moat actually is

Not the schema. Three things, and it is the combination that is defensible:

1. **A longitudinal per-plot and per-animal event record**, captured offline, in the field, by the farmer.
2. **On-device inference** — the primary feature works at zero connectivity, which no advisory platform in India offers.
3. **Calibrated refusal** — the model reports what it does not know, and that refusal routes to a real human. Disease-detection apps with 95% lab accuracy have shown under 10% field adoption; honesty plus escalation is the documented fix.

Any one of these is copyable. All three, plus the record, is a product.

---

## 3. Scope lock

### 3.1 The only four features being built

| # | Problem Statement ask | `SPEC.md` | Where it lives |
|---|---|---|---|
| 1 | Crop disease identification | A1 | Camera FAB → result screen |
| 2 | Livestock monitoring | B1–B5 | `पशु` tab |
| 3 | Historical farm records | A2, C1 | `बही` tab (unified timeline) |
| 4 | Actionable advisory | D1–D3 | Mic pill + `होम` alerts |

Plus the fifth, unstated but scored: *"intuitive and accessible interface suitable for rural environments."* Sections 4–7 exist entirely to win that one.

### 3.2 Cut from the build → PPT Future Scope only

Mandi prices (D4) · schemes (D5) · WhatsApp channel (E2) · VLAE network (E5) · outbreak map (E7) · gender lens (E6) · skin-condition photo assist (B6) · year-on-year comparison (C2) · everything in `SPEC.md` ROADMAP.

### 3.3 Field problems that are framing, not features

| Problem | Already answered by | PPT line |
|---|---|---|
| Middleman / price capture | Feature 3 (records) | RBI, 16 states, 9,400 respondents: farmer gets **28%** of consumer price for potato, **33%** onion, **49%** rice. A record is the first step to a bargaining position |
| Soil | Feature 3 — `plot.soil_type` already exists and feeds the advisory prompt | No new screen |
| Weather prediction | Feature 4 (D3) | IMD's AI monsoon system, launched **11 May 2026**, 1 km block-level, 4 weeks ahead, 3,000+ sub-districts. We consume it, we don't build it |

> Adding a screen for any of these breaks the ≤2-tap rule in §5. Amplify in the *pitch*, not the *build*.

### 3.4 Deltas `SPEC.md` still needs

| Location | Was | Now |
|---|---|---|
| §6 Architecture | React Native + Expo | **Kotlin + Jetpack Compose** |
| §6 stack, local store | expo-sqlite | **Room** (JSON payload stored as `TEXT`, not JSONB — Room has no JSONB type) |
| §9 competitor table | 7 rows | **Add Kisan Sarathi as row one** |
| §2 Fact 3 | "Nobody has unified crop + livestock" | "No platform holds a **longitudinal field-captured record** of both" — the original claim is falsifiable |
| Title / §1 | Kisan Saarthi | **BAHI** |

---

## 4. Day Zero — the cold-start design

**This section did not exist in v1 and it is the most important addition.**

The problem: every feature except the scan assumes months of logged history. On install, the timeline is blank, the advisory has nothing to reference, and the differentiator is invisible. A judge asking *"where did this timeline data come from?"* must not receive the answer "we seeded it."

**Design law: BAHI must be useful on day one with zero manual logging, and the timeline must never be empty.**

Four mechanisms, in order of how much they carry:

### 4.1 Auto-generated future events — the big one

The moment a farmer adds one animal (name, species, approximate age), the vaccination engine writes **future** events into the timeline immediately: FMD, HS, BQ, Brucella, deworming, computed from species and DOB against `vaccination_schedule.json`. Same for a plot: adding a crop and sowing date generates expected irrigation, top-dressing and harvest windows.

Result: **one animal + one plot = 8–12 timeline entries before the farmer has typed anything else.** The record starts full and gets fuller.

### 4.2 Recall backfill — 60 seconds, optional, high value

One screen immediately after profile setup. Voice-led, chip-based, no keyboard:

```
"पिछली बार खेत में क्या बोया था?"
[ गेहूँ ] [ मक्का ] [ सरसों ] [ बाजरा ] [ चना ] [ और… ]

"कब?"      ← month wheel, defaults to a sensible season
"कोई बीमारी लगी थी?"   [ हाँ ] [ नहीं ] [ याद नहीं ]
```

Three taps writes three retrospective events. Now `पिछले साल भी इसी प्लॉट में` is a claim the advisory can actually make in week one instead of year two. Skippable, and re-offered once from the timeline empty state.

### 4.3 Zero-tap capture

- **Every scan writes an event automatically.** The most-used feature is also the highest-quality data source, and it costs the farmer nothing.
- **Notification actions.** The vaccine reminder carries a `हो गया` button — logging happens from the lock screen, zero taps inside the app.
- Weather and season markers append themselves daily.

### 4.4 The timeline is never blank

Records has three zones: **आने वाला** (upcoming, from §4.1) · **आज** · **बीता हुआ**. On day one, zones 1 and 2 have content. The empty state for zone 3 is an invitation, not a void:

> "अभी पुराना रिकॉर्ड खाली है. 1 मिनट में पिछली फ़सल जोड़ दें?" `[ जोड़ें ]`

### 4.5 Demo honesty

Use a seeded account with three months of history, **and label it on screen: `डेमो खाता`**. Then run §4.2 live on a fresh install to show how the history got there. Volunteering the seeding is what converts a weakness into a credibility point — the same instinct as the *Do NOT cite* list in `SPEC.md` §11.

---

## 5. Navigation

```
┌──────────────────────────────────────────┐
│  [🌐 हिन्दी]        बही           [⚙]   │  language always visible
│                                          │
│              screen content              │
│                                          │
│         ╭──────────────────────╮         │
│         │  🎤   पूछो            │         │  persistent advisory pill
│         ╰──────────────────────╯         │
│   ┌────┐  ┌────┐  ╭────╮ ┌────┐ ┌────┐  │
│   │ 🏠 │  │ 🌱 │  │ 📷 │ │ 🐄 │ │ 📖 │  │
│   │होम │  │खेत │  ╰────╯ │पशु │ │ बही│  │
│   └────┘  └────┘   SCAN  └────┘ └────┘  │
└──────────────────────────────────────────┘
```

- Every one of the 4 features is **1 tap from anywhere**. No hamburger. No drawer. No nested tabs.
- Deepest path is **2 taps**. The symptom checker is 3, and it is a guided wizard, not navigation.
- **Advisory is a pill, not a tab** — you invoke it, you don't browse it. Answers land in `होम`.
- The camera FAB is the largest, brightest element on screen. Most-used action, and the demo's opening move.
- The `बही` tab is named after the app on purpose. The record *is* the product.

### Screen inventory — 18 screens

| # | Screen | Purpose |
|---|---|---|
| 0 | Splash | 800ms; warm the TFLite interpreter |
| 1 | Language | pick before anything is spoken |
| 2–5 | Onboarding ×4 | loss · price · rules · the app |
| 6 | Login | phone + inline OTP |
| 7 | Quick profile | name, village, pincode, khet/pashu/dono |
| **8** | **Day Zero setup** | **first plot + first animal, voice-led (§4)** |
| **9** | **Recall backfill** | **optional, 60s, populates history (§4.2)** |
| 10 | Home | today, alerts, mic |
| 11 | Camera | live quality hint |
| 12 | Scan result | three tier skins |
| 13 | खेत | plots → detail → log |
| 14 | पशु | animals → detail → symptom / milk / vaccine |
| 15 | बही | unified timeline, 3 zones |
| 16 | Advisory sheet | listen → answer → speak |
| 17 | Settings | flat list, six rows |

---

## 6. Theme

### 6.1 Palette — the confidence system *is* the colour system

| Token | Hex | Role |
|---|---|---|
| `bahi_green` | `#1B5E20` | primary — brand, nav selected, confident results |
| `bahi_green_dark` | `#0F3D14` | pressed, status bar |
| `bahi_green_soft` | `#DCEFD8` | confident card fill, crop rows |
| `scan_orange` | `#D84315` | **camera FAB only** — one bright thing, one job |
| `verify_amber` | `#B26A00` | tier 2 "being verified" |
| `verify_amber_soft` | `#FFF3DC` | tier 2 fill |
| `urgent_red` | `#B3261E` | tier 3, vet-urgent, overdue |
| `urgent_red_soft` | `#FCEBEA` | tier 3 fill |
| `bg` | `#FAF8F3` | warm off-white — less glare than pure white |
| `surface` | `#FFFFFF` | cards |
| `outline` | `#D6D3CB` | 1dp borders (we use borders, not shadows) |
| `ink` | `#171512` | primary text |
| `ink_soft` | `#4B4740` | secondary text — **never lighter** |

Contrast floor **4.5:1**. `ink_soft` on `bg` passes; anything lighter fails in sunlight and is banned. Light mode only in v1 — dark mode is a demo-room preference, not a field one.

### 6.2 Type

| Role | Size | Weight |
|---|---|---|
| Onboarding headline | 32sp | 700 |
| Screen title | 24sp | 700 |
| Card title | 20sp | 600 |
| **Body (default)** | **18sp** | 400 |
| Button / label | 17sp | 600 |
| Caption / source | 14sp | 400 |

**Noto Sans Devanagari for everything**, including English. One family across Devanagari and Latin; mixing a Latin display face with a Devanagari body face is the most common way Indian-language apps end up looking broken. Line height 1.5. Max ~40 Hindi characters per line. **Never all-caps** — Devanagari has no case, so caps buttons force a visual mismatch.

### 6.3 Shape and space

Spacing 4/8/16/24/32dp · screen padding 16dp · card radius 16dp · button radius 12dp · FAB 72dp circular · **minimum touch target 56dp, primary buttons 64dp full-width** · 1dp border instead of shadow everywhere except the FAB (shadows read as mud on cheap LCDs) · icons 28dp minimum.

### 6.4 Seven UI laws

1. **No icon without a text label.** Ever.
2. **One primary action per screen.** If you can name two, split the screen.
3. **Every advisory text block has a working 🔊.**
4. **Colour never carries meaning alone** — every tier also has an icon and a word: ✓ `पक्का` / ⏳ `जाँच हो रही है` / ⚠ `विशेषज्ञ देखेगा`.
5. **No empty state without an action** in the same card.
6. **The UI never waits for the network.** Write to Room, render, sync later.
7. **Offline is a state, not an error.** Styled green, never red.

### 6.5 Motion — deliberately almost none

150ms fade for screen transitions · 200ms card expand · the mic pill pulses only while listening · the FAB has no entrance animation. That is the entire spec. Every additional animation costs frames on the device this is built for, and reads as decoration to a jury. `Respect reduce-motion`. The one exception: the scan result card **fades in over 250ms with the tier colour resolving last** — the one-frame moment where the app decides how confident it is. Spend the boldness there and nowhere else.

### 6.6 Accessibility

- Every composable has a `contentDescription`; TalkBack reads the screen in a sensible order.
- Layouts survive system font scaling to **1.3×** without clipping — test it, most apps fail here.
- Touch targets 56dp minimum, verified with Layout Inspector.
- No information conveyed by colour alone (law 4).
- Tap-to-hear on every card, not just advisory text.

### 6.7 Theme files

`ui/theme/Color.kt`
```kotlin
package com.bahi.ui.theme
import androidx.compose.ui.graphics.Color

val BahiGreen       = Color(0xFF1B5E20)
val BahiGreenDark   = Color(0xFF0F3D14)
val BahiGreenSoft   = Color(0xFFDCEFD8)
val ScanOrange      = Color(0xFFD84315)
val VerifyAmber     = Color(0xFFB26A00)
val VerifyAmberSoft = Color(0xFFFFF3DC)
val UrgentRed       = Color(0xFFB3261E)
val UrgentRedSoft   = Color(0xFFFCEBEA)
val Bg              = Color(0xFFFAF8F3)
val Surface         = Color(0xFFFFFFFF)
val Outline         = Color(0xFFD6D3CB)
val Ink             = Color(0xFF171512)
val InkSoft         = Color(0xFF4B4740)
```

`ui/theme/Type.kt`
```kotlin
// res/font/noto_sans_devanagari_{regular,semibold,bold}.ttf
val BahiType = Typography(
    displayLarge = TextStyle(fontFamily = Noto, fontWeight = FontWeight.Bold,     fontSize = 32.sp, lineHeight = 40.sp),
    titleLarge   = TextStyle(fontFamily = Noto, fontWeight = FontWeight.Bold,     fontSize = 24.sp, lineHeight = 32.sp),
    titleMedium  = TextStyle(fontFamily = Noto, fontWeight = FontWeight.SemiBold, fontSize = 20.sp, lineHeight = 28.sp),
    bodyLarge    = TextStyle(fontFamily = Noto, fontWeight = FontWeight.Normal,   fontSize = 18.sp, lineHeight = 27.sp),
    labelLarge   = TextStyle(fontFamily = Noto, fontWeight = FontWeight.SemiBold, fontSize = 17.sp, lineHeight = 24.sp),
    bodySmall    = TextStyle(fontFamily = Noto, fontWeight = FontWeight.Normal,   fontSize = 14.sp, lineHeight = 20.sp)
)
```

`ui/theme/Dimens.kt`
```kotlin
object Dim {
    val screenPad = 16.dp; val cardRadius = 16.dp; val btnRadius = 12.dp
    val minTarget = 56.dp; val primaryBtnH = 64.dp; val fabSize = 72.dp
    val borderW = 1.dp;    val tileSize = 96.dp
}
```

---

## 7. Component library — build these first

Everything after these is assembly. Five are marked ★ because they carry the design system.

| Component | Spec |
|---|---|
| ★ `TierCard` | 2dp border + soft fill in tier colour, 16dp radius, icon + word + percentage badge, slot for body, one action slot. Three variants driven by one enum. |
| ★ `SpeakButton` | 48dp circular, 28dp icon; idle / playing / unavailable states; calls `BhashiniTts.speak()`; falls back to Android TTS if Bhashini is unreachable. |
| ★ `MicPill` | 56dp tall, full-width minus 32dp, floats 12dp above the bottom bar, pulses while listening, always on top. |
| ★ `EventRepository` | Not UI, but every write in the app goes through it. Room first, sync queue second, never blocks. |
| ★ `ConfidenceRouter` | Pure function: `Float -> Tier`. Thresholds in one place so calibration changes don't touch the UI. |
| `PrimaryButton` | 64dp, full-width, 12dp radius, 17sp semibold, disabled state 38% alpha. |
| `BahiCard` | white, 1dp `outline`, 16dp radius, 16dp padding, no elevation. |
| `LabeledIcon` | icon 28dp + label 14sp underneath. Enforces law 1 by construction. |
| `BigYesNo` | two 96dp stacked buttons, green filled / white outlined. |
| `EmptyState` | illustration + one line + one action button, all in one card. |
| `OfflineChip` | small green chip, `बिना नेटवर्क चल रहा है`. Never red. |
| `BahiBottomBar` | 4 labelled tabs + centre 72dp FAB. |
| `TimelineRow` | date · icon · subject · one line · optional 56dp thumbnail; crop rows tinted. |

---

## 8. Screen-by-screen

Copy is Hindi-first. Every string lives in `strings_{lang}.json` — adding a language is a file drop, not a rebuild.

### 0 · Splash `800ms`
Wordmark **बही** on `bg`. No spinner. Background: open Room, load the TFLite interpreter so the first scan is instant.

### 1 · Language
Comes before the slides, because the slides talk and we don't yet know in which language. It is also the cheapest possible trust signal: the app speaks *your* language before it asks for anything.

2-column grid, 64dp tiles, **each language in its own script** — `हिन्दी` `English` `मराठी` `ਪੰਜਾਬੀ` `বাংলা` `తెలుగు`. Tapping speaks a one-line sample before confirming. v1 ships Hindi + English functional; the rest are visible with a `जल्द आ रहा है` tag — **do not fake them, a judge will tap one.**

### 2–5 · Onboarding, four slides

```
┌────────────────────────────┐
│      illustration          │  55%, full-bleed
├────────────────────────────┤
│  BIG NUMBER                │  40sp, bahi_green
│  Headline, 2 lines max     │  32sp bold
│  One supporting line       │  18sp ink_soft
│  स्रोत: XYZ                 │  14sp — always present
│  ● ○ ○ ○        [ आगे → ] │
│  छोड़ें                      │  top-right
└────────────────────────────┘
```

Each slide **auto-plays a spoken line** and can be skipped at any point. The voice-over is the primary channel; the statistic is support. That ordering is what keeps these slides from being pitch material aimed at judges rather than farmers. Shown once (DataStore flag), re-openable from Settings.

The source line on every slide is deliberate: it is how the app earns the trust that `SPEC.md` §2 Fact 1 names as the real bottleneck, and it pre-empts *"where did that number come from?"*

**Slide 1 — the loss**
> **26%**
> हर साल फसल कीट और बीमारी से बर्बाद होती है
> सही समय पर सलाह मिले तो नुकसान 10% तक घट सकता है।
> *स्रोत: Ama Krushi RCT, ओडिशा सरकार / PxD*

**Slide 2 — the price** *(the middleman slide)*
> **28%**
> आलू के दाम का सिर्फ इतना हिस्सा किसान तक पहुँचता है
> प्याज़ 33%, चावल 49%। बाकी बीच में चला जाता है।
> *स्रोत: RBI अध्ययन, 16 राज्य, 9,400 किसान*

Illustration: one rupee split into slices, the farmer's slice small and green.

**Slide 3 — the new rules**
> **7.63 करोड़**
> किसान अब डिजिटल पहचान से जुड़ चुके हैं
> AgriStack Farmer ID · DPDP क़ानून 2023 — डेटा आपका, कभी भी मिटाएँ · IMD का नया AI मौसम अनुमान, 1 किमी, 4 हफ़्ते पहले
> *स्रोत: DAHD · IMD*

**Slide 4 — what BAHI is.** No statistic. A labelled diagram of the real home screen:
```
📷 → "पत्ता दिखाओ, बीमारी पहचानो"
🎤 → "बोलकर पूछो, जवाब सुनो"
🐄 → "पशु का टीका, दूध, बीमारी"
📖 → "खेत और पशु — एक ही बही में"
🌐 → "भाषा यहाँ बदलें"
```
Button becomes **शुरू करें**. This slide replaces a tutorial overlay: the home screen is already familiar the first time it appears.

### 6 · Login
One screen. `+91` fixed, 10-digit field at 24sp with wide letter-spacing, keyboard auto-opens. `OTP भेजें` (64dp). After send, the field slides up and six OTP boxes appear **on the same screen** — no navigation. SMS Retriever auto-fills. Resend as a 30s countdown. Errors are specific: *"यह नंबर 10 अंकों का नहीं है"*, never "Invalid input".

### 7 · Quick profile
नाम · गाँव · पिनकोड · **आप क्या करते हैं?** as three large image cards (`खेती` / `पशुपालन` / `दोनों`). Q4 is the only branch in the app — it decides the landing tab. **No land title required** (`SPEC.md` E6): a deliberate inclusion decision worth one PPT line, since land-title requirements exclude tenant farmers and most women.

### 8 · Day Zero setup `new`
Two cards, one screen: `+ पहला खेत जोड़ें` and `+ पहला पशु जोड़ें`. Both open voice-first sheets — speak or tap, keyboard optional. Plot: name, area in bigha, soil type (this is where the soil problem is answered), GPS with manual override. Animal: name, species, breed, approximate age, photo.

The moment either is saved, §4.1 fires and the timeline fills. Show that: a toast reading **"8 काम आपकी बही में जुड़ गए"**.

### 9 · Recall backfill `new` — see §4.2
Skippable. Re-offered once from the timeline empty state and never again.

### 10 · Home
Answers exactly one question: **मुझे आज क्या करना है?** Not a dashboard. No charts.

```
🌐 हिन्दी        बही         ⚙
─────────────────────────────
☀ 32° · कल बारिश          🔊
─────────────────────────────
⚠ आज ज़रूरी
गौरी का FMD टीका 12 दिन में
[ याद दिलाओ ]
─────────────────────────────
बही में हाल का
12 अग · खेत A · झुलसा 87%
10 अग · गौरी · 5.2 लीटर दूध
[ सब देखें → ]
       ╭──────────────────╮
       │  🎤 कुछ भी पूछो   │
       ╰──────────────────╯
  होम   खेत  [📷]  पशु  बही
```

Alert cards obey `SPEC.md` D2 — what / when / how much / why, plus cost-benefit, threshold-triggered only. **If nothing crossed a threshold, no card appears.** An empty urgent section is a feature; it is what prevents the alert fatigue that kills generic SMS advisory. Weather is one line and is not tappable — do not build a weather screen.

### 11 · Camera
Full-bleed CameraX. On screen: a rounded green guide frame, one instruction line (*"पत्ते को पास से, रोशनी में"*), a 72dp shutter, a gallery thumbnail, a flash toggle. Nothing else — no filters, no zoom UI, no ratio picker.

**Live quality hint:** run the Laplacian-variance check on the preview stream. Blurry or dark → frame turns amber and the line changes to *"थोड़ा पास आओ / ज़्यादा रोशनी चाहिए"*. **The shutter stays enabled** — warn, never block.

### 12 · Scan result — the most important screen in the app

**Tier 1 · >0.85** — green border, green_soft fill, ✓
```
✓ पक्का — मक्का का झुलसा रोग            87%
गंभीरता: स्तर 2 (मध्यम)                    🔊
──────────────────────────────────────
क्या करें   मैंकोज़ेब 2.5 ग्राम / लीटर
कब         आज शाम 4 बजे से पहले (कल बारिश है)
खर्चा       ₹380
बचत        लगभग ₹3,000 का नुकसान बचेगा
──────────────────────────────────────
[ बही में जोड़ें ]
```

**Tier 2 · 0.60–0.85** — amber, ⏳
```
⏳ शायद मक्का का झुलसा — जाँच हो रही है   72%
KVK विशेषज्ञ को भेज दिया है। जवाब आते ही बताएँगे।
केस नंबर: BH-2481                          🔊
[ ठीक है ]
```
**No treatment plan is shown.** A dosage at 72% confidence is exactly the failure this product exists to prevent.

**Tier 3 · <0.60** — red, ⚠
```
⚠ हम पक्का नहीं बता सकते
कोई अंदाज़ा नहीं लगाएँगे। विशेषज्ञ से बात करें।   🔊
[ 📞 किसान कॉल सेंटर — 1800-180-1551 ]
[ दूसरी फ़ोटो लें ]
```
**No disease name at all.** Not even a guess.

> **Demo instruction:** this screen — not Tier 1 — is your highest-scoring moment. Rehearse: *"It refuses to guess. That refusal is why a farmer trusts it the second time."*

Every tier writes an `event` immediately, offline, before any network call.

### 13 · खेत
Plot cards → detail → a bottom sheet of six chips (बुवाई · सिंचाई · छिड़काव · खाद · कटाई · खर्च). Voice logging works here: *"मक्का बोया, 15 जून, 2 बीघा"* → parsed → **a pre-filled form is always shown for confirmation.** Never save straight from speech.

### 14 · पशु
Animal cards with a status chip: `टीका बाकी` (red) / `दूध कम` (amber) / `ठीक` (green).

Detail = 2×2 grid of 96dp tiles: `🩺 बीमारी?` · `🥛 दूध दर्ज` · `💉 टीका` · `📅 प्रजनन`, then recent events.

**Symptom checker** — the only wizard. One question per screen, two 96dp buttons, progress bar, back arrow, questions read aloud automatically. 3–6 questions from `symptom_tree.json`, fully offline. Result uses the same three tier skins. An urgent branch shows `[ 📞 1962 ]` as the single primary action.

**Milk log** — numeric pad, not a text field. If the anomaly rule fires (<85% of the 7-day average for 3 days), an amber card appears immediately. **Ship the false-positive caveat in the card copy** — *"पक्का नहीं, पर जाँच लो"* — because yield swings with feed, lactation stage and heat, and a judge will find that if you claim certainty.

**Vaccination** — upcoming + overdue, one `[ हो गया ]` per row, mirrored as a notification action.

### 15 · बही — the timeline
Three zones (`आने वाला` · `आज` · `बीता हुआ`), filter chips `सब · खेत · पशु` with **`सब` as the permanent default** — the merged view *is* the differentiator, and splitting it by default hides the one thing no competitor has. Crop rows tinted `green_soft`, animal rows white: enough to read the mix at a glance, not enough to look like two lists. Sticky month headers.

Demo note: scroll this slowly. The interleaving is the point.

### 16 · Advisory sheet
Bottom sheet over the current screen, never a navigation.
1. **Listening** — large mic, live waveform, *"सुन रहे हैं…"*, cancel.
2. **Thinking** — the transcription shown as text so the farmer can see it was heard right.
3. **Answer** — max 4 lines (`SPEC.md` D1 constraint), auto-played aloud, with 🔊 replay, a source line (*"ICAR के अनुसार"*), 👍/👎, and `[ बही में सहेजें ]`.
4. **Offline** — *"नेटवर्क आने पर जवाब मिलेगा"*, queued, **styled as success, not error.**

A keyboard toggle exists for literate users and, practically, for demoing in a noisy hall.

### 17 · Settings
Six rows, flat: `भाषा बदलें` · `आवाज़ की गति` · `स्लाइड फिर देखें` · `मेरा डेटा मिटाएँ` · `मदद` · `बही के बारे में`.

`मेरा डेटा मिटाएँ` is DPDP Act 2023 compliance and **must report the count of records deleted**. One line, one screenshot, one scoring point.

---

## 9. Escalation — every tier ends somewhere real

v1's tiers routed into a queue that was never built. Fixed:

| Tier | Confidence | Where it actually goes | What the farmer sees |
|---|---|---|---|
| 1 | > 0.85 | resolved in-app | diagnosis + treatment + cost |
| 2 | 0.60–0.85 | queued locally with a **case number**, surfaced to the nearest KVK contact; the farmer can also carry the case number to a KVK or raise it on Kisan Sarathi | "जाँच हो रही है", case number visible |
| 3 | < 0.60 | **Kisan Call Centre 1800-180-1551**, one tap to dial | no diagnosis at all, dial button |
| Vet-urgent | symptom tree urgent branch | **1962** veterinary helpline, one tap | urgency + dial button |

Three rules: **the case number is generated and shown offline**; **the dial button is a real `ACTION_DIAL` intent**, not a mock; **nothing promises a response time we cannot keep** — v1's *"4 ghante mein jawab milega"* is removed everywhere.

> Verify both helpline numbers before the demo. Dialling a dead number on stage is worse than not having the button.

---

## 10. Project structure

```
app/src/main/java/com/bahi/
├── BahiApp.kt                      Application, DI init
├── MainActivity.kt                 single activity, hosts NavHost
├── ui/
│   ├── theme/                      Color.kt · Type.kt · Dimens.kt · Theme.kt
│   ├── components/                 §7 — build these first
│   │   ├── TierCard.kt ★           SpeakButton.kt ★       MicPill.kt ★
│   │   ├── PrimaryButton.kt        BahiCard.kt            LabeledIcon.kt
│   │   ├── BigYesNo.kt             EmptyState.kt          OfflineChip.kt
│   │   ├── TimelineRow.kt          BahiBottomBar.kt
│   ├── onboarding/                 SplashScreen · LanguageScreen · OnboardingScreen (pager, reads JSON) · OnboardingViewModel
│   ├── auth/                       LoginScreen · ProfileScreen · AuthViewModel
│   ├── dayzero/  ★                 DayZeroScreen · RecallBackfillScreen · DayZeroViewModel
│   ├── home/                       HomeScreen · HomeViewModel
│   ├── crop/                       CropScreen · PlotDetailScreen · AddPlotScreen · CropViewModel
│   ├── scan/                       CameraScreen · ScanResultScreen · ScanViewModel
│   ├── livestock/                  LivestockScreen · AnimalDetailScreen · SymptomCheckerScreen
│   │                               MilkLogScreen · VaccinationScreen · LivestockViewModel
│   ├── records/                    RecordsScreen · RecordsViewModel
│   ├── advisory/                   AdvisorySheet · AdvisoryViewModel
│   ├── settings/                   SettingsScreen
│   └── nav/                        BahiNavHost.kt · Routes.kt
├── data/
│   ├── local/
│   │   ├── BahiDatabase.kt         Room
│   │   ├── entity/                 Farmer · Plot · Animal · Event · Advisory   ← SPEC.md §5 verbatim, ONE event table
│   │   ├── dao/                    FarmerDao · PlotDao · AnimalDao · EventDao · AdvisoryDao
│   │   └── PrefsStore.kt           DataStore: language, onboarding_seen, session
│   ├── remote/                     BahiApi.kt (Retrofit → FastAPI) · SupabaseAuth.kt · dto/
│   ├── repository/                 EventRepository.kt ★ · ScanRepository.kt · AdvisoryRepository.kt · SyncManager.kt (WorkManager)
│   └── json/                       loaders for §11
├── domain/  ★
│   ├── ScheduleGenerator.kt        §4.1 — the cold-start engine
│   ├── MilkAnomaly.kt              rolling average + threshold
│   └── BreedingCalendar.kt         21-day heat, 283-day gestation
├── ml/
│   ├── CropClassifier.kt           TFLite INT8 (stub until the model lands)
│   ├── ImageQualityCheck.kt        Laplacian variance
│   ├── ConfidenceRouter.kt ★       thresholds live here and nowhere else
│   └── SymptomTreeEngine.kt        walks JSON, offline
├── voice/                          BhashiniTts · BhashiniAsr · LocaleManager
└── util/                           DateUtils · NetworkMonitor · Constants

app/src/main/assets/
  crop_model.tflite · labels.txt · symptom_tree.json · treatment_plans.json
  vaccination_schedule.json · onboarding.json · strings_hi.json · strings_en.json

app/src/main/res/
  font/ noto_sans_devanagari_{regular,semibold,bold}.ttf
  drawable/ onboarding art, empty states, logo
  values/ colors.xml (mirrors Color.kt) · themes.xml
```

---

## 11. JSON contracts

Content lives in JSON, not Kotlin. Pitch copy, vet logic and treatment plans can then be edited the night before the demo, by someone who is not the Android dev, without a rebuild.

**`onboarding.json`**
```json
{ "slides": [ {
  "id": 1, "illustration": "slide_loss",
  "stat":     { "hi": "26%", "en": "26%" },
  "headline": { "hi": "हर साल फसल कीट और बीमारी से बर्बाद होती है",
                "en": "Lost to pest and disease every year" },
  "body":     { "hi": "सही समय पर सलाह मिले तो नुकसान 10% तक घट सकता है।",
                "en": "Timely advisory has cut severe crop loss by 10%." },
  "source":   "Ama Krushi RCT, Govt of Odisha / PxD",
  "voice_over": { "hi": "…", "en": "…" }
} ] }
```

**`vaccination_schedule.json`** — drives §4.1, so it is now load-bearing
```json
{ "cattle": [
  { "vaccine": "FMD", "first_dose_days": 120, "repeat_days": 180,
    "label": { "hi": "खुरपका-मुँहपका", "en": "FMD" } },
  { "vaccine": "HS",  "first_dose_days": 180, "repeat_days": 365,
    "label": { "hi": "गलघोंटू", "en": "HS" } }
] }
```

**`symptom_tree.json`** — 40–60 nodes
```json
{ "root": "fever",
  "nodes": {
    "fever":    { "q": { "hi": "क्या बुखार है?" },        "yes": "off_feed", "no": "milk_drop" },
    "off_feed": { "q": { "hi": "क्या खाना छोड़ दिया?" },  "yes": "res_urgent_01", "no": "udder" }
  },
  "results": {
    "res_urgent_01": { "likely": { "hi": "संक्रमण की आशंका" },
                       "action": { "hi": "तुरंत डॉक्टर को दिखाएँ" },
                       "urgency": "urgent", "needs_vet": true }
  } }
```

**`treatment_plans.json`** — keyed by model label, each with `what` / `dose` / `when` / `cost_inr` / `saves_inr` / `source`. Exactly the five rows the Tier 1 card renders, so the card needs zero logic.

**`strings_hi.json` / `strings_en.json`** — every UI string. **No hardcoded strings in Kotlin. Not one.**

---

## 12. Stitch prompts

Prepend to every prompt:

> Android app for Indian farmers. Light mode only. Background #FAF8F3, white cards with a 1dp #D6D3CB border and 16dp radius, no drop shadows. Primary green #1B5E20, alert amber #B26A00, urgent red #B3261E, camera button #D84315. Font Noto Sans Devanagari. Body text 18sp minimum, buttons 64dp tall and full width. Hindi labels in Devanagari. Every icon has a text label under it. Large touch targets, very high contrast, readable in bright sunlight. Minimal, one primary action per screen. No gradients, no glassmorphism, no smiling stock-photo farmers.

| # | Screen | Prompt |
|---|---|---|
| 1 | Language | 2-column grid of six large tiles, each showing a language in its own script — हिन्दी, English, मराठी, ਪੰਜਾਬੀ, বাংলা, తెలుగు — each with a small speaker icon. Bottom four dimmed with a 'जल्द आ रहा है' tag. |
| 2 | Onboarding | Top 55% an illustration of a diseased maize leaf. Below: a very large green '26%', a bold two-line Hindi headline, one supporting line, a small grey source line, four page dots with the first filled, a full-width green 'आगे' button, a small 'छोड़ें' link top-right. |
| 3 | Login | Hindi title 'मोबाइल नंबर डालें', a fixed '+91' prefix, a large widely letter-spaced 10-digit field, a full-width green 'OTP भेजें' button, and below it a row of six separate square OTP boxes with a grey resend countdown. |
| 4 | Day Zero | Two large stacked cards, '+ पहला खेत जोड़ें' with a sprout icon and '+ पहला पशु जोड़ें' with a cow icon, each with one line of Hindi helper text and a microphone icon indicating voice input. A skip link at the bottom. |
| 5 | Home | Top bar with a globe and 'हिन्दी' left, 'बही' centred, a gear right. A one-line weather strip. A red-bordered urgent card 'गौरी का FMD टीका 12 दिन में' with a button. A 'बही में हाल का' section with three compact rows mixing crop and animal entries. A wide green microphone pill 'कुछ भी पूछो' floating above the bottom bar. Bottom navigation with four labelled tabs — होम, खेत, पशु, बही — and a large circular orange camera button raised in the centre. |
| 6 | Scan result, confident | A card with a thick green border and pale green fill, a checkmark, 'मक्का का झुलसा रोग', an '87%' badge, a speaker icon, and four labelled rows: क्या करें, कब, खर्चा, बचत. One full-width green button 'बही में जोड़ें'. |
| 7 | Scan result, uncertain | Same layout but amber — thick #B26A00 border, #FFF3DC fill, hourglass icon, 'शायद मक्का का झुलसा — जाँच हो रही है', a 72% badge, a case number line, two lines of Hindi explanation, no treatment details at all, one outlined button 'ठीक है'. |
| 8 | Animal detail | Header with a cow photo, 'गौरी', and breed. Below, a 2×2 grid of four large square tiles with big icons and Hindi labels: बीमारी?, दूध दर्ज, टीका, प्रजनन. Below that, a list of recent activity rows with dates. |
| 9 | Symptom checker | Full-screen single question. Thin progress bar showing step 2 of 5. Large Hindi question 'क्या खाना छोड़ दिया?' with a speaker icon. Two enormous stacked buttons, 'हाँ' green filled and 'नहीं' white with green outline, each about a quarter of the screen height. Back arrow top-left. Nothing else. |
| 10 | Timeline | Three filter chips — सब selected, खेत, पशु. A section header 'आने वाला' with two upcoming rows, then 'बीता हुआ' with a scrolling list grouped by sticky month headers. Crop rows have a pale green tint and a plant icon, animal rows are white with a cow icon. Each row: date, subject, one line of description; some with a small square thumbnail. |
| 11 | Advisory | Bottom sheet over a dimmed home screen. The transcribed question in grey Hindi at the top. Below, a white answer card with four lines of Hindi advice, a speaker icon, a small 'ICAR के अनुसार' source line, thumbs up and down icons, and a full-width 'बही में सहेजें' button. |

---

## 13. Build order and risk register

| Step | Deliverable | Unblocks |
|---|---|---|
| 1 | Theme + the five ★ components | everything |
| 2 | Room entities + DAOs (`SPEC.md` §5 verbatim, **one event table**) | all data work |
| 3 | NavHost + bottom bar + empty tabs | parallel screen work |
| 4 | Language → onboarding → login → profile | first run complete |
| 5 | **Day Zero + `ScheduleGenerator`** | **the timeline stops being empty** |
| 6 | Timeline (3 zones) | differentiator visible |
| 7 | CameraX + TFLite + `ConfidenceRouter` + `TierCard` | **demo centrepiece** |
| 8 | Symptom checker + escalation dial intents | livestock is real |
| 9 | Advisory sheet + Bhashini | **the closing demo moment** |
| 10 | Milk log, reminders, sync, airplane-mode test | polish |

### Risk register

| Risk | Severity | Mitigation |
|---|---|---|
| Model not ready by step 7 | **high** | Ship a stub `CropClassifier` returning a fixed label and a **configurable confidence** — it also makes rehearsing all three tier screens trivial |
| Nobody on the team has shipped Compose | **high** | Decide in the next 48 hours. Reversing to React Native is only cheap right now |
| Bhashini fails on hall wifi | **high** | Android TTS fallback wired into `SpeakButton`; a pre-recorded audio path for the demo; rehearse the failure |
| Field accuracy lands at 75–85% | medium | That is the correct number to report — but only with the confusion matrix on the slide (§14.2) |
| Milk anomaly false positives | medium | Caveat in the card copy; state the false-positive rate |
| Helpline numbers wrong | medium | Verify 1962 and 1800-180-1551 by dialling, before the demo |
| Scope overrun | medium | Steps 1–7 are the demo. 8–10 are bonus. Cut from the bottom |

---

## 14. Demo

### 14.1 The two-minute script

```
1. Fresh install. Language → slides → login → add खेत A (मक्का) + गौरी.   25s
   → "8 काम बही में जुड़ गए." The record is populated before anything is typed.
2. Airplane mode ON. Scan a diseased leaf. Diagnosis appears.              20s
   → "No internet. The model is on the phone."
3. Scan a hard leaf. 72%. It refuses. Case number appears.                20s
   → "It will not guess. That refusal is why a farmer trusts it twice."
4. Symptom checker on गौरी: fever + reduced milk → vet urgent → 1962.     20s
5. Open बही. Crop and animal, one feed, three zones.                      10s
6. Ask aloud: "अब मुझे क्या करना चाहिए?"                                  35s
   → The answer references the blight just detected, tomorrow's rain,
     AND गौरी's overdue FMD vaccine — three domains, one sentence.
   → "No other platform in India holds all three facts about one farmer."
```

**Step 6 is the whole pitch.** Build everything else to make step 6 land. Note the change from v1: the money line is now the FMD-vaccine cross-reference, not stover-as-fodder — because Indian farmers have used stover as fodder for generations, and an ICAR judge will know that.

### 14.2 The model card slide — one slide, four numbers

Field-set accuracy · model size in MB · inference latency in ms **on a named cheap phone** · the confusion matrix. Report accuracy on a **held-out field-image test set**, never the PlantVillage split — that number is inflated and everyone in the room knows it. These four beat any architecture diagram, and they are what make the honesty story credible rather than convenient.

---

## 15. Judge Q&A defence

Rehearse these. Each answer is under twenty seconds.

**"Kisan Sarathi already does this, and it's ours."**
> Kisan Sarathi is the country's expert answer network — 2.95 crore farmers, 4,767 scientists. We don't compete with it, we feed it. It has no per-farmer field record and no offline diagnosis, because those can only be captured in the field without a network. Our low-confidence cases escalate into that network with the context the expert would otherwise have to ask for.

**"Your own document says apps don't reach marginal farmers."**
> Correct, and the government's own numbers prove it: of 2.95 crore Kisan Sarathi registrations, about 21,000 came through mobile apps. That's why we treat this app as the capture layer for the farmer who does have a phone — and why WhatsApp is the next channel, not a nice-to-have.

**"Where did that timeline data come from?"**
> This is a demo account, labelled on screen. Here's how a real one fills — [run Day Zero live] — one animal and one plot generate eight entries before anything is typed.

**"A single event table isn't a moat."**
> Agreed, the schema is a week of work. The moat is the combination: a field-captured longitudinal record, on-device inference that works at zero connectivity, and a model that reports what it doesn't know and routes it to a human.

**"What's your accuracy?"**
> [Real field-set number]. Lower than the PlantVillage figure other teams will quote, because we test on field images. Here's the confusion matrix, and here's what happens below 60% confidence — nothing. No guess.

**"Who pays for this at scale?"**
> We haven't invented unit economics we can't defend. What we can say: inference is on-device so 90% of scans cost nothing, and the natural institutional buyers are state departments and FPOs. We are not selling farmer data — that would contradict our consent layer.

---

## 16. Pre-demo QA checklist

- [ ] Airplane mode: scan works, symptom tree works, writes queue, timeline renders
- [ ] All three tier states reachable on demand (keep a known-hard leaf in the gallery)
- [ ] Day Zero runs clean on a fresh install in under 60 seconds
- [ ] Demo account visibly labelled `डेमो खाता`
- [ ] Both helplines dialled and confirmed live
- [ ] Every visible string comes from `strings_hi.json`
- [ ] Zero icons without labels
- [ ] Every advisory block has a working 🔊, with the fallback path tested
- [ ] Font scaling at 1.3× — no clipping on any screen
- [ ] Contrast checked on the **demo phone at 100% brightness**, not the emulator
- [ ] `मेरा डेटा मिटाएँ` works and reports a real count
- [ ] Cold start under 3 seconds on the target device
- [ ] Two-minute script rehearsed end to end, twice, including the Bhashini failure

---

## 17. Decisions still needed from you

1. **The name.** BAHI, or an alternate — but check the Play Store and trademark register first. Everything else in this document is find-and-replaceable; a name collision on stage is not.
2. **Compose or React Native.** 48-hour window. If nobody has shipped Compose, this decision costs you the demo.
3. **Languages in v1.** Recommend Hindi + English functional, four visible with `जल्द आ रहा है`. Confirm the four.
4. **Onboarding art.** Photograph for slide 1 (a real diseased leaf carries more weight than an icon), flat vector for 2–4. Five assets to source or draw.
5. **minSdk.** Recommend API 24. Lower loses Compose conveniences, higher excludes real farmer devices.
6. **Who owns the Colab run.** It is the critical path for step 7 and no amount of UI work unblocks it.

---

*Every figure here traces to `SPEC.md` §11 or to a cited public source. Nothing has been invented. New numbers go into that table first, with a source, or they do not go on a slide.*

---
name: BAHI Utility System
colors:
  surface: '#f8f9fa'
  surface-dim: '#d9dadb'
  surface-bright: '#f8f9fa'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f4f5'
  surface-container: '#edeeef'
  surface-container-high: '#e7e8e9'
  surface-container-highest: '#e1e3e4'
  on-surface: '#191c1d'
  on-surface-variant: '#414844'
  inverse-surface: '#2e3132'
  inverse-on-surface: '#f0f1f2'
  outline: '#717973'
  outline-variant: '#c1c8c2'
  surface-tint: '#3f6653'
  primary: '#012d1d'
  on-primary: '#ffffff'
  primary-container: '#1b4332'
  on-primary-container: '#86af99'
  inverse-primary: '#a5d0b9'
  secondary: '#526351'
  on-secondary: '#ffffff'
  secondary-container: '#d5e8d1'
  on-secondary-container: '#586957'
  tertiary: '#002d1c'
  on-tertiary: '#ffffff'
  tertiary-container: '#00452e'
  on-tertiary-container: '#75b393'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#c1ecd4'
  primary-fixed-dim: '#a5d0b9'
  on-primary-fixed: '#002114'
  on-primary-fixed-variant: '#274e3d'
  secondary-fixed: '#d5e8d1'
  secondary-fixed-dim: '#b9ccb6'
  on-secondary-fixed: '#101f11'
  on-secondary-fixed-variant: '#3b4b3a'
  tertiary-fixed: '#b1f0ce'
  tertiary-fixed-dim: '#95d4b3'
  on-tertiary-fixed: '#002114'
  on-tertiary-fixed-variant: '#0e5138'
  background: '#f8f9fa'
  on-background: '#191c1d'
  surface-variant: '#e1e3e4'
typography:
  headline-lg:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
  headline-sm:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 14px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  margin-mobile: 16px
  gutter-mobile: 12px
---

## Brand & Style

The design system is engineered for Indian farmers, prioritizing extreme utility, high legibility in outdoor environments, and a sense of agricultural reliability. The brand personality is grounded, trustworthy, and efficient. 

The aesthetic follows a **Modern Minimalism** approach with a **Flat** execution. It avoids complex effects like shadows or gradients in favor of high-contrast structural elements. By using a "1dp border" logic, the UI remains organized and legible even under high-glare sunlight. The interface should feel like a digital ledger—functional, honest, and uncomplicated.

## Colors

The color palette is derived from agricultural landscapes to foster immediate familiarity. 

- **Primary (#1B4332):** A deep, saturated forest green used for active states, primary buttons, and critical navigation elements. It provides the necessary contrast ratio for outdoor readability.
- **Secondary (#DCEFD8):** A pale, soothing mint green used exclusively for row highlights, selected states, and soft backgrounds to group related information without adding visual weight.
- **Neutrals:** A range of clean whites and cool greys (#F8F9FA to #212529) are used for backgrounds and text to ensure a "paper-like" clarity.
- **Functional Colors:** Use a clear red for errors/warnings and the tertiary green for success states or positive financial trends.

## Typography

The design system utilizes **Inter** for all text roles. This typeface was selected for its exceptional tall x-height and clear letterforms, which are vital for users who may be viewing the screen at arm's length or in bright sunlight.

- **Legibility First:** Body text never drops below 14px to ensure accessibility for all age groups.
- **Emphasis:** Use Semibold (600) for headers and data labels to create a clear visual hierarchy against the flat background.
- **Numeric Clarity:** Since this is a utility/ledger tool, ensure tabular figures (monospaced numbers) are used for all currency and quantity displays to keep columns aligned.

## Layout & Spacing

The layout is based on a **4px baseline grid** to ensure mathematical consistency. 

- **Grid:** A standard 4-column fluid grid for mobile.
- **Margins:** 16px lateral margins are mandatory for all screens to prevent content from hitting the edge of device cases.
- **Touch Targets:** All interactive elements (chips, list items, buttons) must maintain a minimum height of 48px to accommodate larger fingers and physical use cases.
- **Vertical Rhythm:** Use 16px (md) spacing between distinct cards or list groups, and 8px (sm) between related items within a group.

## Elevation & Depth

This design system deliberately avoids shadows. Depth is communicated through **Tonal Layering** and **Structural Outlines**:

- **Borders:** Use a 1px solid border (#E0E0E0) for all cards and input fields.
- **Surface Tiering:** The base background is white (#FFFFFF). Secondary information containers use the neutral grey (#F8F9FA). 
- **Active State:** Highlighted rows or active containers utilize the Pale Green tint (#DCEFD8) with no additional border change, providing a soft but clear distinction.
- **Focus State:** When an input is focused, the 1px border changes from grey to Primary Green (#1B4332).

## Shapes

The shape language is **Soft**, striking a balance between the precision of a professional tool and the approachability of a mobile app.

- **Components:** Standard buttons, input fields, and cards use a 4px (0.25rem) corner radius.
- **Chips:** Filter chips use the `rounded-xl` (12px/0.75rem) setting to distinguish them from rectangular data cards.
- **Icons:** Use "filled" icons for primary actions and "outlined" icons for secondary navigational elements, ensuring they follow a consistent 2px stroke weight to match the border logic.

## Components

### Buttons
- **Primary:** Filled Primary Green (#1B4332) with white text. 4px radius.
- **Secondary:** 1px border of Primary Green with Primary Green text. No fill.

### Filter Chips
- **Unselected:** 1px grey border, white background, grey text.
- **Selected:** Filled Primary Green with white text. Includes a "check" icon prefix.

### List Rows (Ledger Style)
- **Container:** 1px bottom border for separation.
- **Date Marker:** A dedicated left-aligned column with a 12px label font, often styled with a subtle grey background circle for the day.
- **Interaction:** On press, the background transitions to the Pale Green highlight (#DCEFD8).

### Input Fields
- **Style:** 1px solid border. Label sits above the field in Label-MD styling.
- **Validation:** Error states use a 1px Red (#D90429) border with an assistive text label below.

### Cards
- **Style:** White background, 1px grey border, 4px corner radius. Used to group "Crops," "Weather," or "Market Prices." 
- **Header:** Cards should include a bold 16px title with an optional trailing icon for "expand" or "details."